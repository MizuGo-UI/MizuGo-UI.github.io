---
title: Linux入门
tags: Linux
---

# Shell编程

### 执行方式

1. 作为可执行程序

   ```shell
   chmod +x ./test.sh #使脚本具有执行权限
   ./test.sh #执行脚本
   ```

   需要先cd到对应的目录，否则会报错找不到对应的文件

2. 作为解释器参数

   ```shell
   /bin/sh test.sh
   /bin/php test.php
   ```

### shell变量

> 命名规则
>
> - 命名只能使用英文字母，数字和下划线，首个字符不能以数字开头
> - 中间不能有空格，可以使用下划线 _
> - 不能使用标点符号
> - 不能使用bash里的关键字（可用help命令查看保留关键字）

```shell
name="yr"
str="name is ${name}"#双引号中可以带有变量
-> name is yr
str1='name is ${name}'#单引号会直接将内容直接输出.
-> name is ${name}
```

变量{}可以不加
