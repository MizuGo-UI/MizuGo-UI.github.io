---
title: 关于idea配置中遇到的坑
date: 2021-01-07 10:14:23
urlname:
categories:
tags:
---

​       配置idea时一定弄清楚http proxy，这是http代理，个人理解相当于是VPN，配置了这个后而导致gradle无法正常下载，从而引发了一系列问题，谨记。