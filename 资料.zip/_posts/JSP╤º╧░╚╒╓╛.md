---
title: JSP学习日志
tags: JAVA
date: 2021-9-10 09:07:04
---

## 第一节 HTML

HTML（Hyper Text Markup Language）：超文本标记语言

<!--more-->

### W3C标准

- 结构化标准语言：HTML、XML
- 表现标准语言：CSS
- 行为标准语言：DOM、ECMAScript

### HTML基本结构

```html
<head>
    网页头部
</head>

<body>
	主体部分
</body>
```

### 注释

<!- -注释- - >

### <meta>标签

- 描述性标签，用来描述网站的一些相关信息

- 用来做SEO（搜索引擎优化）

### 网页基本标签

```html
<!--标题标签-->
<h1>一级标签</h1>
<h2>二级标签</h2>
<h3>二级标签</h3>
<h4>二级标签</h4>
<h5>二级标签</h5>
<h6>二级标签</h6>

<!--段落标签-->
<p>跑得快 跑得快</p>

<p>两只老虎</p>

<p>按住Tab可快捷生成标签</p>

<!--换行标签-->
跑得快 跑得快 <br/>

两只老虎 <br/>

p按住Tab键快捷 <br/>

<!--水平线标签-->
<hr/>

<!--粗体，斜体-->
<h1>字体样式标签</h1>
<p>粗体  <strong>变粗</strong></p>
<p>斜体 <em>变斜</em></p>

<!--特殊符号-->
空格： 空&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;格
<br/>
&gt;   >
<br/>
&lt;   <
<br/>
&copy;版权
```

### 图像标签

```HTML
<img src = “../resources/image/1.jpg(图片地址）" alt = “图片名称" title =
        “MizuGo" width="100" height="100">
```

src 图片路径地址  ../  代表上一级地址 

alt 图片名称；往往用于备注说明，当图片加载未成功时显示

title 悬停图片上所显示的文字

### 链接标签

#### 超链接标签

<a>标签

href:表示要跳转到的页面（必填）

target:表示页面要打开的位置

​	_blank:表示在新标签页打开

​	\_self：表示在当前标签页打开（默认）_

<!--文字链接形式-->

```HTML
<a href="http:\\\www.baidu.com" target="_blank">点击跳转到百度</a>
```

<!--图片链接形式-->

```HTML
<a>
   <img src="../resources/image/1.jpg" alt="图片" title="悬停文字">`
</a>
```

#### 锚链接

1. 需要一个标记
2. 跳转到该标记

<!--用name属性作标记-->

```HTML
<a name="tag">tag</a>
```

<!--用#+name跳转到对应的标记-->

```HTML
<a href="#tag">回到标记处</a>
```

#### 功能性链接

<!--邮件链接-->

mailto

```HTML
<a href="mailto:406587247@qq.com">点击联系我</a>
```

<!--QQ链接-->

QQ推广中获取

```html
<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=406587247&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:406587247:53" alt="你好加我好友" title="你好加我好友"/></a>
```



### 列表

<!--有序列表-->

```html
<ol>
    <li>Java</li>
    <li>C++</li>
    <li>Python</li>
</ol>
```



效果图如下：

<ol>
    <li>Java</li>
    <li>C++</li>
    <li>Python</li>
</ol>

<!--无序列表-->

```html
<ul>
    <li>Java</li>
    <li>C++</li>
    <li>Python</li>
</ul>
```

效果图如下：

<ul>
    <li>Java</li>
    <li>C++</li>
    <li>Python</li>
</ul>
<!--自定义列表-->

```html
<!--dl：标签
dt:列表名称
dd:列表内容
多用于网站底部内容-->
<dl>
    <dt>语言</dt>
    <dd>Java</dd>
    <dd>C++</dd>
    <dd>Python</dd>
    <dt>程度</dt>
    <dd>1</dd>
    <dd>2</dd>
    <dd>3</dd>
</dl>
```

效果图如下：

<dl>
    <dt>语言</dt>
    <dd>Java</dd>
    <dd>C++</dd>
    <dd>Python</dd>
    <dt>程度</dt>
    <dd>1</dd>
    <dd>2</dd>
    <dd>3</dd>
</dl>
### 表格

```html
<!--tr:行
td:列
-->
<!--border 边框-->
<table border="1px">
  <tr>
<!--colspan 跨列-->
    <td colspan="2">1-1</td>
    <td>1-2</td>
    <td>1-3</td>
  </tr>
  <tr>
   <!--rowspan 跨行-->
    <td rowspan="2">2-1</td>
    <td>2-2</td>
    <td>2-3</td>
  </tr>
  <tr>
    <td >3-1</td>
    <td>3-2</td>
    <td>3-3</td>
  </tr>
    
```

效果图如下：

<table border="1px">
    <tr>
    	<td cospan="2">1-1</td>
     	<td>1-2</td>
        <td>1-3</td>
    </tr>
    <tr>
    	<td rowpan="2">2-1</td>
     	<td>2-2</td>
        <td>2-3</td>
    </tr>
    <tr>
    	<td >3-1</td>
     	<td>3-2</td>
        <td>3-3</td>
    </tr>
</table>
### 媒体元素

```html
<!--src：资源路径
controls：控制条（无此项会导致资源不显示）
autoplay：自动播放-->

<!--视频元素-->
<video src="../resources/video/1.mp4 controls autoplay" width="300px" height="600px"></video>
<!--音频元素-->
<audio src="../resources/video/2.mp3 controls"></audio>
```

<!--视频元素-->



效果图如下：

<video src="../video/1.mp4" width="300px" height="600px"></video>

<!--音频元素-->

效果图如下：

<audio src="../video/2.mp3"></audio>

### 页面结构分析

```html
<!--header：头部
section：主体
footer：脚部
nav：导航类-->
<header><h2>网页头部</h2></header>

<section><h2>网页主体</h2></section>

<footer><h2>网页脚部</h2></footer>
```

### 内联框架

```html
<!--iframe：内联框架

src:路径

name:内联框架名

width：宽

height：高-->
<!--导入其他网页-->
<iframe src="http://www.bilibili.com" frameborder="0"></iframe>
```

效果图如下：

<iframe src="https://www.bilibili.com" frameborder="0" width="400px" height="300px"></iframe>



```html
<!--b站视频导入-->
<iframe src="//player.bilibili.com/player.html?aid=632543773&bvid=BV1qb4y1S7p4&cid=396396792&page=1" width="400px" height="300px"scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>
```

效果图如下：

<iframe src="//player.bilibili.com/player.html?aid=632543773&bvid=BV1qb4y1S7p4&cid=396396792&page=1" width="400px" height="300px"scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>



```html
<!--利用超链接导入自己的网页-->
<iframe src="" frameborder="0" name="hello" width="400px" height="300px"></iframe>

<a href="1.MyFirstWeb.html" target="hello"></a>
```

可实现在内联框架中打开自己的网页

### 表单post和get的提交

```html
<!--表单form
name：表单名（必填）
action：表单提交的位置，可以为网站，也可以是请求处理的地址
methon：表单提交方式（post、get）
get方式提交：可以在url中看到提交的信息，不安全
post方式提交：比较安全，可以提交大文件
value:默认值-->
<form action="www.baidu.com" methon="post">
    <p>注册：
        <br>
        用户名<input type="text" name="用户名" value="username">
        密码<input type="password" name="密码" value="password">
    </p>    
</form>
<p>
    <input type="submit">
    <input type="reset" value="清空">
</p>
```

效果如下：理论上来说点击提交会跳转到百度

<form action="www.baidu.com" methon="post">
    <p>注册：
<br>
        用户名<input type="text" name="用户名" value="username">
        密码<input type="password" name="密码" value="password">
    </p>    
</form>



<p>
    <input type="submit">
    <input type="reset" value="清空">
</p>



```html
<!--单选框标签
input type="radio"
value:单选框的值
需要让同一组的name相同-->
<p>
    <input type="radio" value="boy" name="sex">男
    <input type="radio" value="girl" name="sex">女
</p>
```

效果如下：

<p>
    <input type="radio" value="boy" name="sex">男
    <input type="radio" value="girl" name="sex">女
</p>



```html
<!--多选框标签
input type="checkbox"-->
<p>爱好：
    <input type="checkbox" value="a" name="hobby">睡觉
    <input type="checkbox" value="b" name="hobby">打游戏
    <input type="checkbox" value="C" name="hobby">看书
</p>
```

效果如下：

<p>爱好：
  <input type="checkbox" value="a" name="hobby">睡觉
    <input type="checkbox" value="b" name="hobby">打游戏
    <input type="checkbox" value="C" name="hobby">看书	
</p>



```html
<!--button按钮
image图像
value：按钮所显示的文字-->
<p>
    <input type="button" name="btn1" value="变长">
	<input type="image" src="../../source/images/JSP学习日志/1.png">
</p>
```

效果如下：

<p>
    <input type="button" name="btn1" value="变长">
	<input type="image" src="../../source/images/JSP学习日志/1.png">
</p>

```html
<!--滑块-->
<p>音量
    <input type="range" name="voice" max="100" min="0">
</p>
```

效果如下：

<p>音量
    <input type="range" name="voice" max="100" min="0">
</p>



```html
<!--搜索框-->
<p>搜索框
    <input type="search" name="search">
</p>
```

效果如下：

<p>搜索框
    <input type="search" name="search">
</p>



```html
<!--列表
selected默认选项-->
<p>列表
    <select>国家
        <option>中国</option>
        <option selected>美国</option>
        <option>英国</option>
    </select>
</p>
```

效果如下：

<p>列表
    <select>国家
        <option>中国</option>
        <option selected>美国</option>
        <option>英国</option>
    </select>
</p>



```html
<!--文本域-->
<p>反馈
    <textarea name="textarea" cols="20" rows="10">文本内容</textarea>
</p>
```

效果如下：

<p>反馈
    <textarea name="textarea" cols="20" rows="10">文本内容</textarea>
</p>



```html
<!--文件域-->
<p>添加文件
    <input type="file" name="file">
    <input type="button" name="upload" value="上传">
</p>
```

效果如下：

<p>添加文件
    <input type="file" name="file">
    <input type="button" name="upload" value="上传">	
</p>


### 表单的限制

- disabled：不可操作
- hidden：隐藏
- readonly：只读

```html
<!--增强鼠标可用性-->
<p>
    <label for="tag">点击试试（点击汉字会跳转到文本框）</label>
    <input type="text" id="tag">
</p>
```

效果如下：

<p>
    <label for="tag">点击试试（点击汉字会跳转到文本框）</label>
    <input type="text">
</p>

### 表单初级验证

```html
<!--提示信息-->
<p>文本框
    <input type="text" name="text" placeholder="请输入">
</p>
```

效果如下：

<p>文本框
    <input type="text" name="text" placeholder="请输入">
</p>



```html
<!--非空判断-->
<p>url
    <input type="url" name="url" required>
</p>
```

效果如下：

<p>url
    <input type="url" name="url" required>
</p>



```html
<!--自定义邮箱
https://www.jb51.net/tools/regexsc.htm正则表达式网站-->
<p>自定义邮箱
    <input type="text" name="diymail" pattern="">
</p>
```



<hr/>

## 第二节 CSS

CSS：层叠级联样式表

### CSS的优势

1. 内容和表现分离
2. 网页结构表现统一，可以实现复用
3. 样式十分的丰富
4. 建议使用独立于html的css文件
5. 利用SEO，容易被搜索引擎收录

### CSS的3中导入方式

行内样式：

```html
<!--行内样式-->
<h4 style="color:red">我是标题
</h4>
```

效果如下：

<h4 style="color:red">我是标题
</h4>


内部式

<!--内部式-->

```html
<style>
    h4{
        color:blue;
    }
</style>
<h4>
    我是标题
</h4>
```


效果如下：

<style>
    h4{
        color:blue;
    }
</style>
<h4>
    我是标题
</h4>


外部式：

​		外部式较前两种而言更加规范，往往采用这种方式。

​		涉及到两个文件，html文件和css文件

css文件：

```html
h4{
color:green;
}
```

html文件：

```html
<h4>
    我是标题
</h4>
<!--将html文件与css文件链接起来-->
<link rel="stylesheet" href="css/style.css">
```

优先级：

​		遵循覆盖原则，按行加载，因此后加载的会将之前加载的覆盖掉

### 选择器

标签选择器

```html
<!--标签选择器-->
<style>
    h4{
        color:red;
    }
</style>
<h4>
    标签1
</h4>
<h4>
    标签2
</h4>
```

效果如下：

<style>
    h4{
        color:red;
    }
</style>
<h4>
    标签1
</h4>
<h4>
    标签2
</h4>


类选择器

```html
<!--类选择器-->
<style>
    .BQ1{
        color:blue;
    }
    .BQ2{
        color:green;
    }
</style>
<h4 class="BQ1">
    标签1
</h4>
<h4 class="BQ2">
    标签2
</h4>
```

PS:

> ​	可以复用，对应相同类的有相同样式
>

id选择器

```html
<!--id选择器-->
<style>
    #BQ{
      color: coral;
    }
    .style1{
        color: blue;
    }
  </style>
<h4 class="style1">标签1</h4>
<h4 id="BQ">标签2</h1>
<h4 class="style1">标签3</h4>
```

PS:

> ​		不可以复用，当需要指定某一个标签改变样式时，使用id
>
> 选择器优先级问题：
>
> ​		id选择器>class选择器>标签选择器
>

### 属性选择器

​			属性选择器是将id选择器和类选择器结合的一种选择器。

格式为：

​		a[属性名]{对应的属性}

<hr/>

## 第三节 JSP

### 引入JavaScript

1.内部标签

```html
<script>
  alert("hello world")
</script>
```

2.外部引入

a.js

```js
alert("hello world")
```

test.html

```html
<script src="js/a.js"></script>
```

PS：

> 不用定义type，也默认是JavaScript
>

```html
<script type="text/javascript"></script>
```

### 基本语法入门

1.定义变量  变量类型  变量名 = 变量值

```html
<script>
var score =1
alert(score);
</script>
```

2.条件控制

```javascript
if(score>60&&score<70){
    alert(true);
}else{
    alert(false);
}
//console.log();在浏览器控制台中打印信息
```

### 数据类型

0.变量

```javascript
var la
//不能以数字开头，var在方法内部定义为局部变量，在方法外部定义为全局变量
let la
//定义局部变量
```

1.number

js不区分小数和整数

```javascript
123//整数
123.1//浮点数
1.123e3//科学计数法
-999/负数
NaN//not a number
Infinity//无限大
```

2.字符串 

```javascript
'abc'  "abc"
```

多行字符串编写

```javascript
let name = `11
			22
			33`
```

模板字符串

```javascript
let name = `11
		   22
		   33`
let msg = `你好,${name}`
```

字符串长度

```javascript
str.length
```

PS：

> 字符串有不可变性



3.布尔值

```javascript
true false
```

4.逻辑运算

```javascript
&& 和
|| 或
！ 非
```

5.比较运算符

```javascript
=
== 等于（类型不一样，值一样，也会判断为true)
=== 绝对等于(类型一样，值一样，判断为true)
```

PS：

> - NaN与所有的数值都不相等，包括自己
> - 只能通过isNaN(NaN)来判断这个数是否是NaN
>

浮点数问题：

```javascript
console.log((1/3)===(1-2/3)
```

​		尽量避免使用浮点数进行运算，存在精度问题

6.null和undefined

- null 空
- undefined 未定义

7.数组

Java的数组必须是一系列相同类型的对象；在JavaScript中不需要这样

```javascript
var arr=[1,2,3,null,true,"hello"]
```

取数组下标，如果越界了，就会undefined，并不会像java一样报错

长度

```javascript
arr.length
```

PS：

> 加入给arr.length赋值，数组大小就会发生变化（数组是动态的），如果赋值过小，元素就会丢失
>
> 字符串的"1"和数字1是不同的

slice( )

截取array的一部分，返回一个新数组，包头不包尾

push( )、pop( )

```javascript
push:压入到尾部
pop:弹出尾部的一个元素
```

unshift( )、shift( )

```javascript
unshift:压入到头部
shift：弹出头部的一个元素
```

concat( )

```javascript
var arr1 = ['c','b','a']
arr1.concat([1,2,3])
>(6)['c','b','a',1,2,3]
```

PS:

> concat( )并没有修改数组，只是会返回一个新的数组

多维数组

```javascript
arr = [[1,2],[2,3],[3,4]]
arr[0]
>[1,2]
arr[0][1]
>2
```

8.对象

对象是{ },数组是[ ]

> 每个属性之前用逗号隔开，最后一个不需要添加

```javascript
var 对象名 = {
    属性名：属性值
    属性名：属性值
    属性名：属性值
}

//Java创建对象
//Person person = new Person(1,2,3);
var person = {
    name:"yr",
    age:22,
    tags:['js','java','web']        
}
```

取对象的值

```javascript
person.name
>"yr"
person.age
>22
```

动态的删减属性，通过delete删除对象的属性

```javascript
delete person.name
>true
```

动态的添加，直接给新的属性添加值即可

```javascript
person.email="400@123.com"
>"400@123.com"
```

判断属性是否在这个对象中：xxx   in   xxx

```javascript
'age' in person
>true
//继承
'toString' in person
>true
```

判断属性值是否在这个对象中   has

```javascript
person.hasOwnProperty("toString")
>false
person.hasOwnProperty("age")
>true
```



PS:

> 'use strict';   严格检查模式，预防JavaScript的随意性导致产生的一些问题，必须写在JavaScript的第一行
>
> js中对象，{······}表示一个对象，键值对描述属性xxxx:xxxx，多个属性之间使用逗号隔开，最后一个属性不加逗号 
>
> 使用一个不存在的对象属性，不会报错，只会报undefined

9.流程控制

if判断

```javascript
var age = 3;
if(age>3){
    alert("1");
}else if(age<5){
    alert("0");
}else{
    alert("hah");
}
```

while循环，避免程序死循环

```javascript
var age = 3;
while(age<100){
    age=age+1;
}
```

for循环

```javascript
for (var i = 0; i < things.length; i++) {
		console.log(thing[i])
}
```

forEach循环

```javascript
var age = [1,2,3,4,5,6,7];

//函数
age.forEach(function (value){
    console.log(value)
})
```

for···in···    得到对应的索引

for···of···    得到对应的值

```javascript
for(var num in age){
	if(age.hasOwnProperty(num)){
		console.log(age[num]);
	}
}

for(var num of age){
	if(age.hasOwnProperty(num)){
		console.log(num);
	}
}
```

