---
title: Static小记
tags: Java
---

## 概述

static方法就是没有this的方法。在static方法内部不能调用非静态方法，反过来是可以的。而且可以在没有创建任何对象的前提下，仅仅通过类本身来调用static方法。

即说明了主要用途就是：

<font color=#FF0000>  方便在没有创建对象的情况下来进行调用（方法/变量） </font> 

<!--more--> 

> static关键字修饰的方法或者变量不需要依赖于对象来进行访问，只要类被加载了，就可以通过类名去进行访问

## Static方法

又称静态方法，不依赖于任何对象就可以进行访问

但是正因为不依附于任何对象，会出现以下情况

- 静态方法中不能访问类的非静态成员变量和非静态成员方法
- 非静态方法可以访问类的静态成员变量和静态成员方法

## Static变量

又称静态变量

静态变量和非静态变量的区别是：

- 静态变量被所有的对象所共享，在内存中只有一个副本，它当且仅当在类初次加载时会被初始化
- 非静态变量是对象所拥有的，在创建对象的时候被初始化，存在多个副本，各个对象拥有的副本互不影响

static成员变量的初始化顺序按照定义的顺序进行初始化

## static代码块

static块可以置于类中的任何地方，形成静态代码块以优化程序性能

类中可以有多个static块

在类初次被加载的时候，会按照static块的顺序来执行每个static块，并且只会执行一次

对于某些类中的方法在每次被调用的时候，都会创建一次对象，就会导致空间浪费，因此如果用static代码块让其只执行一次就可以优化性能

优化前：

```java
class Person{
    private Date birthDate;
     
    public Person(Date birthDate) {
        this.birthDate = birthDate;
    }
     
    boolean isBornBoomer() {
        Date startDate = Date.valueOf("1946");
        Date endDate = Date.valueOf("1964");
        return birthDate.compareTo(startDate)>=0 && birthDate.compareTo(endDate) < 0;
    }
}
```

优化后：

```java
class Person{
    private Date birthDate;
    private static Date startDate,endDate;
    static{
        startDate = Date.valueOf("1946");
        endDate = Date.valueOf("1964");
    }
     
    public Person(Date birthDate) {
        this.birthDate = birthDate;
    }
     
    boolean isBornBoomer() {
        return birthDate.compareTo(startDate)>=0 && birthDate.compareTo(endDate) < 0;
    }
}
```

<font color=#FF0000>将一些只需要进行一次的初始化操作都放在static代码块中进行</font>