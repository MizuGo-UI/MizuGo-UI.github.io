---
title: Android相对布局
date: 2021-01-16 22:03:04
urlname:
categories:
tags: Android
---

## LinearLayout线性布局

​       线性布局顾名思义主要用于布局分配情况为水平或者竖直的情况,在此基础上对各控件进行位置的设定,同时只有LinearLayout才有权重(weight),可以等比例大小设定控件。

<!--more-->

##  RelativeLayout相对布局

​        相对布局显得更加随意，对于各控件的位置属性也很多，可以将控件设定在任意位置上。

## FrameLayout帧布局

​       帧布局的应用场景较少，所有的控件都会默认摆放在布局的左上角，对于各控件的位置设定也较少。

##  百分比布局

​       百分比布局为一种新增的布局，只为FrameLayout和RelativeLayout进行了功能扩展，提供了PercentFrameLayout和PercentRelativeLayout两个全新的布局。

​      利用app:layout_widthPercent和app:layou_heightPercent来指定宽高

​     

  