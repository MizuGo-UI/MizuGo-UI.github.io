---
title: 关于Android项目过程中的一些认识
date: 2021-01-19 21:03:14
urlname:
categories:
tags: Android
---

写在前面：

​        Android Studio升级到4.1后，之前很多的包都不可用了，需要寻找其他办法。

<!--more-->

 Android Studio 3.4推出了AndroidX要取代原来的support库。创建新项目的时候，如果没有勾选“Use androidx.* artifacts”，那么导入外部模块不会报错；只有勾选了“Use androidx.* artifacts”，导入外部模块才会报上面的错。勾选界面如下图所示：

![](../images/关于Android项目过程中的一些认识/Androidx.png)

如果已经勾选了“Use androidx.* artifacts”，可以在gradle.properties目录下更改信息，如下图：

![](../images/关于Android项目过程中的一些认识/image-20210120154553213.png)

详细的support依赖库的新旧对应关系见下表：

| **支持库的旧路径**                               | **支持库的新路径**                               |
| ------------------------------------------------ | ------------------------------------------------ |
| com.android.support.constraint:constraint-layout | androidx.constraintlayout:constraintlayout:1.1.2 |
| com.android.support.test.espresso:espresso-core  | androidx.test.espresso:espresso-core:3.1.0       |
| com.android.support.test:runner                  | androidx.test: runner:1.1.0                      |
| com.android.support:appcompat-v7                 | androidx.appcompat:appcompat:1.0.0               |
| com.android.support:cardview-v7                  | androidx.cardview:cardview:1.0.0                 |
| com.android.support:design                       | com.google.android.material:material:1.0.0-rc01  |
| com.android.support:multidex                     | androidx.multidex:multidex:2.0.0                 |
| com.android.support:palette-v7                   | androidx.palette:palette:1.0.0                   |
| com.android.support:recyclerview-v7              | androidx.recyclerview:recyclerview:1.0.0         |
| com.android.support:support-v4                   | androidx.legacy:legacy-support-v4:1.0.0          |

详细的support控件的新旧对应关系见下表：

| 支持控件的旧包名                                     | 支持控件的新包名                                        |
| ---------------------------------------------------- | :------------------------------------------------------ |
| android.support.v4.app.Fragment                      | androidx.fragment.app.Fragment                          |
| android.support.v4.app.FragmentActivity              | androidx.fragment.app.FragmentActivity                  |
| android.support.v4.app.FragmentManager               | androidx.fragment.app.FragmentManager                   |
| android.support.v4.app.FragmentPagerAdapter          | androidx.fragment.app.FragmentPagerAdapter              |
| android.support.v4.view.ViewPager                    | androidx.viewpager.widget.ViewPager                     |
| android.support.v4.view.PagerAdapter                 | androidx.viewpager.widget.PagerAdapter                  |
| android.support.v4.view.PagerTabStrip                | androidx.viewpager.widget.PagerTabStrip                 |
| android.support.v4.view.PagerTitleStrip              | androidx.viewpager.widget.PagerTitleStrip               |
| android.support.v7.app.AppCompatActivity             | androidx.appcompat.app.AppCompatActivity                |
| android.support.v7.widget.Toolbar                    | androidx.appcompat.widget.Toolbar                       |
| android.support.v7.widget.RecyclerView               | androidx.recyclerview.widget.RecyclerView               |
| android.support.v7.widget.GridLayoutManager          | androidx.recyclerview.widget.GridLayoutManager          |
| android.support.v7.widget.LinearLayoutManager        | androidx.recyclerview.widget.LinearLayoutManager        |
| android.support.v7.widget.StaggeredGridLayoutManager | androidx.recyclerview.widget.StaggeredGridLayoutManager |
| android.support.v7.widget.CardView                   | androidx.cardview.widget.CardView                       |
| android.support.v7.graphics.Palette                  | androidx.palette.graphics.Palette                       |

## Android项目流程

 从个人理解的角度来说：

​         一个项目的最开始的一步应该是框架的搭建，确定好项目的各个模块的功能。

​         先设想好自己所要实现的功能，将Java代码实现，然后根据Java代码完成xml代码的设计。



## Banner相关的一些认识







## Glide相关的一些认识





## Adapter相关的一些认识



## Bean相关的一些认识

## Gson相关的一些认识

​         首先需要导入Gson的第三方包，且由于Android Studio 4.1无GsonFormat的插件，只能用SGsonFormat代替使用，在操作上基本上一致。

​        将所要解析的数据导入SGson中进行解析会自动得到类中方法。        

下图为json数据解析的具体流程：

![](../images/关于Android项目过程中的一些认识/image-20210202152418181.png)

