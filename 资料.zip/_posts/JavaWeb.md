---
title: JavaWeb
tags: JAVA
---



## 基本概念

### 基本介绍

web开发：

- web，网页

<!--more-->

- 静态web

  - html,css
  - 提供给所有人看的数据始终不会发生变化

- 动态web

  - 淘宝，几乎所有网站
  - 提供给所有人看的数据始终会发生变化
  - 技术栈：Servlet/JSP，ASP,PHP

  在java中，动态web资源开发的技术统称维javaweb
  
  

### web应用程序

web应用程序：可以提供浏览器访问的程序；

- a.html、b.html···多个web资源，这些web资源可以被外界访问，对外界提供服务
- 能访问到的任何一个页面或者资源，都存在于这个世界上某一计算机上
- 统一的web资源会被放在同一个文件夹下，web应用程序->Tomcat:服务器
- 一个web应用由多部份组成
  - html,css,js
  - jsp,servlet
  - java程序
  - jar包
  - 配置文件（Properties）

web应用程序编写完毕后，若想提供给外界访问：需要一个服务器来统一管理；

![](../images/JavaWeb/image-20211026154803740.png)



### 静态web

- \*.html,\*.htm，这些都是网页的后缀，如果服务器上一直存在这些东西，那么就可以访问

![](../images/JavaWeb/image-20211026154837911.png)



### 配置

默认主机名：localhost->127.0.0.1

**网站是如何访问的**

1. 输入一个域名
2. 首先检查本机C:\Windows\System32\drivers\etc\hosts配置文件下有没有这个域名映射
   1. 本机有：直接返回对应的ip地址，这个地址中，有需要访问的web程序，则可以直接访问
   2. 本机没有：去DNS服务器找，找到的话就返回，找不到就返回找不到

![image-20211028154637751](../images/JavaWeb/image-20211028154637751.png)

### 发布一个web网站

> 将自己写的网站，放到服务器（Tomcat）中指定的web应用的文件夹（webapps）下，就可以访问网站

```java
--webapps:Tomcat服务器的web目录
    -ROOT  （默认目录）
    -kuangstudy：网站的目录名
    	-WEB-INF
    		-classes:java程序
            -lib:web应用所依赖的jar包
            -web.xml:网站配置文件
        -index.html：默认的首页
        -static
        	-css
                -style.css
            -js
            -img
```

## HTTP

### 基本介绍

HTTP(超文本传输协议)是一个简单的请求-响应协议，通常运行在TCP之上

- 文本：html，字符串
- 超文本：图片，音乐，视频，定位，地图
- 80

HTTPS：安全

- 443

### 两个时代

- HTTP/1.0:客户端可以与web服务器连接后，只能获得一个web资源，断开连接
- HTTP/2.0:k客户端可以与web服务器连接后，能够获得多个web资源

### HTTP请求

> 客户端--发请求(Request)--服务器

请求百度：

```java
Request URL: https://www.baidu.com/
Request Method: GET		get方法/post方法
Status Code: 200 OK		状态码 200 = ok
Remote Address: 39.156.66.18:443
```

```java
Accept: text/html
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9		语言
Cache-Control: max-age=0
Connection: keep-alive
```

#### **请求行**

- 请求行中的请求方式：GET
- 请求方式：GET,POST， HEAD,DELETE,PUT,TRACT...
  - get:能够携带的参数比较少，大小有限制，会在浏览器的URL地址栏显示数据内容，不安全，但高效
  - post:能够携带的参数比较多，大小无限制，不会在浏览器的URL地址栏显示数据内容，安全，但不高效

#### **消息头**

```JAVA
Accept: 支持的数据类型
Accept-Encoding：支持哪种编码格式 GBK	UTF-8	GB2312	ISO8859-1
Accept-Language: 语言环境
Cache-Control: 缓存控制
Connection: 请求完成断开还是保持连接
HOST：主机
```



### HTTP响应

> 服务器--响应--客户端

百度响应：

```java
Cache-Control: private		缓存控制
Connection: keep-alive		连接
Content-Encoding: gzip		编码
Content-Type: text/html;charset=utf-8		类型
```

#### 响应体

```java
Accept: 支持的数据类型
Accept-Encoding：支持哪种编码格式 GBK	UTF-8	GB2312	ISO8859-1
Accept-Language: 语言环境
Cache-Control: 缓存控制
Connection: 请求完成断开还是保持连接
HOST：主机
Refresh: 刷新时间
Location：让网页重新定位
```

#### 响应状态码

200：请求响应成功

3xx：请求重定向

- 重定向：重新到指定的新位置

4xx：找不到资源  404

- 资源不存在

5xx：服务器代码错误  500  502（网关错误）

## Maven

自动导入和配置jar包

### Maven项目架构管理工具

Maven的核心思想：**约定大于配置**

### 在idea中使用Maven

![image-20211101092050977](../images/JavaWeb/image-20211101092050977.png)

![image-20211101092516885](../images/JavaWeb/image-20211101092516885.png)

### 在idea中使用Tomcat

![image-20211101105815548](../images/JavaWeb/image-20211101105815548.png)

 

## Servlet

### 基本介绍

- Servlet是sun公司开发动态web的一门技术
- sun在这些API中提供的一个接口：Servlet，开发一个Servlet程序，只需要两个步骤：
  - 编写一个类，实现Servlet接口
  - 把开发好的Java类部署到web服务器中

实现了Servlet接口的Java程序就叫做Servlet

### HelloServlet

 **关于Maven父子工程的理解**

父项目：

```java
<modules>
    <module>servlet-01</module>
</modules>
```

子项目：

```java
<parent>
    <artifactId>javaweb-02-servelet</artifactId>
    <groupId>com.MizuGo</groupId>
    <version>1.0-SNAPSHOT</version>
</parent>
```

**编写一个Servlet程序**

1. 编写一个普通类
2. 实现Servlet接口，可直接集成HttpServlet

```java
/*java文件夹*/
public class HelloServlet extends HttpServlet {
    //由于get或者post只是请求实现的不同的方式，可以相互调用，业务逻辑一样
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //ServletOutputStream outputStream = resp.getOutputStream();
        PrintWriter writer = resp.getWriter();//响应流
        writer.print("hello,Servlet");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}
```

**编写Servlet的映射**

原因：写的为Java程序，但是要通过浏览器访问，而浏览器需要连接web服务器，所以需要在web服务中注册我们写的Servlet，还需要设置一个浏览器能够访问的路径

```java
<!--web.xml文件-->
<!--注册Servlet-->
  <servlet>
    <servlet-name>hello</servlet-name>
    <servlet-class>com.servlet.HelloServlet</servlet-class>//对应的java文件
  </servlet>
  <!--Servlet的请求路径-->
<servlet-mapping>
  <servlet-name>hello</servlet-name>//应与上面保持一致
  <url-pattern>/hello</url-pattern>//访问路径
</servlet-mapping>
```

**配置Tomcat**

> PS:此处有个大坑，Tomcat 10修改了包名，在运行的时候首先会加载tomcat自带的servlet-api包，从而导致自己导入的包名与tomcat自带的不一致，报错500

### Servlet运行原理

![image-20211102142518178](../images/JavaWeb/image-20211102142518178.png)

### Mapping问题

1. 一个Servlet可以指定一个映射路径

   ```xml
   <servlet-mapping>
     <servlet-name>hello</servlet-name>
     <url-pattern>/hello</url-pattern>
   </servlet-mapping>
   ```

2. 一个Servlet可以指定多个映射路径

   ```xml
   <servlet-mapping>
     <servlet-name>hello</servlet-name>
     <url-pattern>/hello</url-pattern>
   </servlet-mapping>
   <servlet-mapping>
       <servlet-name>hello</servlet-name>
       <url-pattern>/hello2</url-pattern>
   </servlet-mapping>
   <servlet-mapping>
       <servlet-name>hello</servlet-name>
       <url-pattern>/hello3</url-pattern>
   </servlet-mapping>
   ```

3. 一个Servlet可以指定通用映射路径

   ```xml
   <servlet-mapping>
      <servlet-name>hello</servlet-name>
      <url-pattern>/hello/*</url-pattern></servlet-mapping>
   ```

4. 指定一些后缀或者前缀

   ```xml
     <servlet-mapping>
       <servlet-name>hello</servlet-name>
       <url-pattern>*do</url-pattern>
     </servlet-mapping>
   ```

5. 默认请求路径

   ```XML
     <servlet-mapping>
       <servlet-name>hello</servlet-name>
       <url-pattern>/*</url-pattern>
     </servlet-mapping>
   ```

6. 优先级问题

   > 若已经指定了固定路径，则访问固定路径时不会跳转到通用路径								

### ServletContext

> web容器在启动的时候，会为每个web程序都创建一个对应的ServletContext对象，它代表了当前的web应用，Context凌驾于所有的Servlet之上，不同的Servlet之间可以用Context作为中间商交换数据

#### 共享数据

在这个Servlet中保存的数据，可以在另外一个servlet中拿到，需要优先访问上传数据的页面，再访问获取数据的页面，否则会导致无数据

```java
/*
*HelloServlet.java
*将数据上传到Context
*/
  @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = "yurui";
         ServletContext servletContext = this.getServletContext();
         servletContext.setAttribute("username",username);
    }
```

```java
/*
*GetServlet.java
*获取Context中的数据
*/
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    ServletContext servletContext = this.getServletContext();
    String username = (String)servletContext.getAttribute("username");
    resp.getWriter().print("user"+username);
}
```

```xml
 <servlet>
    <servlet-name>hello</servlet-name>
    <servlet-class>com.servlet.HelloServlet</servlet-class>
  </servlet>
  <servlet-mapping>
    <servlet-name>hello</servlet-name>
    <url-pattern>/hello</url-pattern>
  </servlet-mapping>
  <servlet>
    <servlet-name>get</servlet-name>
    <servlet-class>com.servlet.GetServlet</servlet-class>
  </servlet>
  <servlet-mapping>
    <servlet-name>get</servlet-name>
    <url-pattern>/get</url-pattern>
  </servlet-mapping>
```

#### 获取初始化参数

```java
/*
*ParmaServlet.java
*/
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    ServletContext servletContext = this.getServletContext();
    String url = servletContext.getInitParameter("url");//对应xml文件中初始化参数的名字
    resp.getWriter().print(url);
}
```

```xml
<context-param>
  <param-name>url</param-name>
  <param-value>jdbc:mysql://localhost:3306/mybatis</param-value>
</context-param>

  <servlet>
    <servlet-name>gp</servlet-name>
    <servlet-class>com.servlet.ParamServlet</servlet-class>
  </servlet>
  <servlet-mapping>
    <servlet-name>gp</servlet-name>
    <url-pattern>/gp</url-pattern>
  </servlet-mapping>
```

#### 请求转发

```java
/*
*ServletDemo.java
*/
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    ServletContext servletContext = this.getServletContext();
    servletContext.getRequestDispatcher("/gp").forward(req,resp);//转向路径
}
```

```java
/*
*ParamServlet.java
*/
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    ServletContext servletContext = this.getServletContext();
    String url = servletContext.getInitParameter("url");
    resp.getWriter().print(url);
}
```

```xml
<servlet>
  <servlet-name>gp</servlet-name>
  <servlet-class>com.servlet.ParamServlet</servlet-class>
</servlet>
<servlet-mapping>
  <servlet-name>gp</servlet-name>
  <url-pattern>/gp</url-pattern>
</servlet-mapping>
<servlet>
  <servlet-name>demo</servlet-name>
  <servlet-class>com.servlet.ServletDemo</servlet-class>
</servlet>
<servlet-mapping>
  <servlet-name>demo</servlet-name>
  <url-pattern>/demo</url-pattern>
</servlet-mapping>
```

请求转发流程图：

![image-20211104142038940](../images/JavaWeb/image-20211104142038940.png)

> A请求C的数据
>
> 先访问B，由B转发来自A的请求到C，拿到C的数据后再经过B返回给A（在这个过程中，域名不会改变）

重定向流程图：

![image-20211104143225421](../images/JavaWeb/image-20211104143225421.png)

> A请求C的数据
>
> 先访问B，B返回信息给A数据应该在C处，A收到来自B的信息再去访问C（在这个过程中，域名会发生改变）

> **请求转发和重定向的区别**
>
> 相同点
>
> - 页面都会跳转
>
> 不同点
>
> - 请求转发的时候，url不会产生变化  307
>   - 重定向时候，url地址栏会发生变化  302

#### 读取资源文件

Properties

- 在java目录下新建properties
- 在resources目录下新建properties

发现都被打包到了同一个路径下：classes，俗称为classpath

```java
/*
*ServletDemo2.java
*/
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    ServletContext servletContext = this.getServletContext();
    InputStream in = servletContext.getResourceAsStream("/WEB-INF/classes/db.properties");//相对路径，/代表当前项目目录
    Properties properties = new Properties();
    properties.load(in);//读取流文件
    String username = properties.getProperty("username");
    String type = properties.getProperty("type");
    resp.getWriter().print("<font style='color:red;font-size:60px'>"+username+"</font>");
    resp.getWriter().print(type);
}
```

> properties文件往往放在resources文件夹下，如果放在java文件夹下可能会导致导出失败
>
> ```xml
> <!--需要在该项目的pom.xml文件下添加如下代码-->
> <!--在build中配置resources，来防止我们资源导出失败的问题-->
> <build>
>     <resources>
>         <resource>
>             <directory>src/main/resources</directory>
>             <includes>
>                 <include>**/*.properties</include>
>                 <include>**/*.xml</include>
>             </includes>
>             <filtering>true</filtering>
>         </resource>
>     	<resource>
>             <directory>src/main/java</directory>
>             <includes>
>                 <include>**/*.properties</include>
>                 <include>**/*.xml</include>
>             </includes>
>             <filtering>true</filtering>
>         </resource>
>     </resources>
> </build>
> ```
>
> 打印信息可以添加要打印的相应格式，并以字符串的形式将其连接起来

### HttpServletResponse

web服务器接收到客户端的http请求，针对这个请求，分别创建一个代表请求的HttpServletRequest对象，代表响应的一个HttpServletRequest

- 如果要获取客户端请求过来的参数：找HttpServletRequest
- 如果要获取客户端响应一些信息：找HttpServletResponse

#### 简单分类

**负责向浏览器发送数据的方法**

```java
ServletOutputStream getOutputStream() throws IOException;

PrintWriter getWriter() throws IOException;
```

**负责向浏览器发送响应头的方法**

```java
void setCharacterEncoding(String var1);

void setContentLength(int var1);

void setContentLengthLong(long var1);

void setContentType(String var1);

void setDateHeader(String var1, long var2);

void addDateHeader(String var1, long var2);

void setHeader(String var1, String var2);

void addHeader(String var1, String var2);

void setIntHeader(String var1, int var2);

void addIntHeader(String var1, int var2);
```

#### 常见应用

1. 向浏览器输出消息	
2. 下载文件
   1. 要获取下载文件的路径
   2. 下载的文件名
   3. 设置让浏览器能够支持下载所需的东西
   4. 获取下载文件的输入流
   5. 创建缓冲区
   6. 获取OutputStream
   7. 将FileOutputStream流写入到buffer缓冲区
   8. 使用OutputStream将缓冲区中的数据输出到客户端

```java
/*
*FileServlet.java
*/
@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//1. 要获取下载文件的路径
        String realPath = "D:\\java-1.0-maven\\response\\target\\response\\WEB-INF\\classes\\1.pdf";
//2. 下载的文件名
       String filename = realPath.substring(realPath.lastIndexOf("\\")+1);//lastIndexOf能够取到最后一次出现该字符的位置
//3. 设置让浏览器能够支持下载所需的东西
        resp.setHeader("Content-Disposition","attachment;filename="+filename);
//4. 获取下载文件的输入流
        FileInputStream in = new FileInputStream(realPath);
//5. 创建缓冲区
   int len=0;
   byte [] buffer = new byte[1024];
//6. 获取OutputStream
        ServletOutputStream out = resp.getOutputStream();
//7. 将FileOutputStream流写入到buffer缓冲区,使用OutputStream将缓冲区中的数据输出到客户端
        while((len=in.read(buffer))>0){
            out.write(buffer,0,len);
        }
    in.close();
    out.close();
    }
```

#### 实现重定向

```java
/*
*RedirectServlet.java
*/
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    resp.sendRedirect("/res/down");//res是服务器带有的路径
}
```

```xml
<servlet>
  <servlet-name>file</servlet-name>
  <servlet-class>com.servlet.FileServlet</servlet-class>
</servlet>
<servlet-mapping>
  <servlet-name>file</servlet-name>
  <url-pattern>/down</url-pattern>
</servlet-mapping>
<servlet>
  <servlet-name>red</servlet-name>
  <servlet-class>com.servlet.RedirectServlet</servlet-class>
</servlet>
<servlet-mapping>
  <servlet-name>red</servlet-name>
  <url-pattern>/red</url-pattern>
</servlet-mapping>
```

<hr>

```java
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    resp.sendRedirect("/res/success.jsp");
}

```

```xml
<servlet>
  <servlet-name>req</servlet-name>
  <servlet-class>com.servlet.RequestTest</servlet-class>
</servlet>
<servlet-mapping>
  <servlet-name>req</servlet-name>
  <url-pattern>/login</url-pattern>
</servlet-mapping>
```

```javascript
<%--${pageContext.request.contextPath}代表当前的项目--%>
<form action="${pageContext.request.contextPath}/login" method="get">
    用户名：<input type="text" name="username"> <br>
    密码：<input type="password" name="password"><br>
    <input type="submit">
</form>
```

![image-20211106100242239](../images/JavaWeb/image-20211106100242239.png)

### HttpServletRequest

```java
/*
*LoginServlet.java
*/
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    req.setCharacterEncoding("utf-8");
    resp.setCharacterEncoding("UTF-8");
    String[] parameterValues = req.getParameterValues("hobbys");
    String username = req.getParameter("username");
    String password = req.getParameter("password");
    //后台接收中文乱码问题
    System.out.println(username);
    System.out.println(password);
    System.out.println(Arrays.toString(parameterValues));
    //这里的/代表当前的web应用
    req.getRequestDispatcher("/success.jsp").forward(req,resp);
}
```

```javascript
<%--index.jsp--%>
<div style="text-align: center">
    <form action="${pageContext.request.contextPath}/login" method="post">
        用户名：<input type="text" name="username"><br>
        密码：<input type="password" name="password"><br>
        爱好:
        <input type="checkbox" name="hobbys" value="电影">电影
        <input type="checkbox" name="hobbys" value="唱歌">唱歌
        <input type="checkbox" name="hobbys" value="跳舞">跳舞
        <br>
        <input type="submit">
    </form>
</div>
```

## Cookie、Session

### 会话

**概念**

用户打开一个浏览器，点击了很多超链接，访问多个web资源，关闭浏览器，这个过程可以称为会话

**有状态会话**

一个人去到一个地方，留下了足迹，下次再去到这个地方，其他人知道他已经来过的情况

> **证明访问过一个网站**
>
> cookie：服务端给客户端一个信件，客户端下次访问服务端带上信件即可
>
> session：服务器登记访问过这个网站了，下次再来的时候由服务器来匹配访问的人

### 保存会话的两种技术

cookie

- 客户端技术（响应，请求）

session

- 服务器技术，利用这个技术，可以保存用户的会话信息，我们可以把信息和数据放在session

### Cookie

1. 从请求中拿到cookie信息
2. 服务器响应给客户端cookie

```java
Cookie[] cookies = req.getCookies();//获得cookie
cookie.getName()；//获得cookie中的key
cookie.getValue()；//获得cookie中的value
new Cookie("lastTime",System.currentTimeMillis()+"");//创建一个新的cookie
cookie.setMaxAge(24*60*60);//设置cookie的有效期为一天
resp.addCookie(cookie);//响应给客户端一个cookie
```

> - 一个Cookie只能保存一个信息
> - 一个web站点可以给浏览器发送多个cookie，最多存放20个cookie
> - Cookie大小有限制：4kb
> - 300个cookie为浏览器上限

**删除Cookie**

- 不设置有效期，关闭浏览器则自动失效
- 设置有效期时间为0；

**编码解码**

```java
URLEncoder.encode("中文","utf-8");
URLDecoder.decode(cookie.getValue(),"utf-8");
```

### Session(重点)

**概念**

- 服务器会给每个用户（浏览器）创建一个Session对象
- 一个Session独占一个浏览器，只要浏览器没有关闭，这个Session就存在
- 用户登录之后，整个网站都可以访问；->保存用户信息；保存购物车信息

```java
//得到Session
HttpSession session = req.getSession();
//给Session中存东西
session.setAttribute("name","yr");
//获取Session的id
String id = session.getId();
//判断session是不是新创建
session.isNew();
//从Session中取东西
session.getAttribute("name");
```

**两种注销方式**

```xml
<!--xml中设置失效方式-->
<!--设置Session默认的失效时间-->
<session-config>
  <!--1分钟后Session自动失效，以分钟为单位-->
  <session-timeout>1</session-timeout>
</session-config>
```

```java
//java中注销方式
//手动注销session
session.invalidate();
```

> Session和Cookie区别
>
> - Cookie是把用户的数据写给用户的浏览器，浏览器保存（可以保存多个）
> - Session把用户的数据写到用户独占Session中，服务器端保存（保存重要的信息，减少资源浪费）
> - Session对象由服务创建

**使用场景**

- 保存一个登录用户的信息
- 购物车信息
- 在整个网站中经常会使用的数据，我们将它保存在Session中

## JavaBean

实体类

JavaBean有特定的写法

- 必须有一个无参构造
- 属性必须私有化
- 必须有对应的get/set方法

一般用来和数据库的字段做映射：ORM;

ORM:对象关系映射

- 表->类
- 字段->属性
- 行记录->对象

people表

| id   | name    | age  | address |
| ---- | ------- | ---- | ------- |
| 1    | MizuGo1 | 22   | 西安    |
| 2    | MizuGo2 | 21   | 重庆    |
| 3    | MizuGo3 | 23   | 北京    |

```java
/*
*java中数据库表对应形式
*/
class People{
	private int id;
    private String name;
	private int age;
	private String address;
}

class A{
    new People(1,"MizuGo1",22,"西安")；
    new People(2,"MizuGo2",21,"重庆")；
    new People(3,"MizuGo3",23,"北京")；
}
```

```jsp
<%--类似于创建对象，page表示只在当前页生效--%>
<jsp:useBean id="people" class="com.MizuGo.pojo.People" scope="page"/>
<%--设置属性--%>
<jsp:setProperty name="people" property="address" value="西安"/>
<%--获取属性值--%>
<jsp:getProperty name="people" property="address"/>
```

## MVC三层架构

> 什么是MVC？
>
> MODEL:模型，与数据库对应的实体类
>
> - 控制业务操作、保存数据、修改数据、删除数据、查询数据
>
> View：视图
>
> - 展示数据模型
> - 提供用户操作
>
> Controller：控制器
>
> - 接受用户的数据
> - 交给业务层返回数据
> - 视图跳转

```javascript
登录--->接受用户的登录请求--->处理用户的请求(获取用户的登录的参数：username、password)--->交给业务层处理登录业务(判断用户名密码是否正确)--->Dao层查询用户名和密码是否正确--->数据库
```

