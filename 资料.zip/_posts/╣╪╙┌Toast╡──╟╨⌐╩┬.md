---
title: 关于Toast的那些事
tags: Android
date: 2021-01-17 22:06:44
---



## 1.最基本的Toast

系统自带Toast采用的是队列的方式， 等当前Toast消失后， 下一个Toast才能显示出来；原因是Toast的管理是在队列中，点击一次，就会产生一个新的Toast，要等这个队列中的Toast处理完，这个显示Toast的任务才算结束。 so~ 我们可以把Toast改成单例模式，没有Toast再新建它，这样也就解决了连续点击Toast，一直在显示的问题。

<!--more-->

```java
Toast.makeText(Context,"最基本的Toast",Toast.LENGTH_SHORT).show();
```



## 2.自定义位置的Toast

```java
Toast.makeText(Context,"自定义位置的Toast",Toast.LENGTH_SHORT);
toast.setGravity(Gravity.LEFT,50,0);              
toast.show();
```



## 3.自定义布局（带图片）的Toast

```java
Toast customToast = new Toast(MainActivity.this.getApplicationContext());
 //获得view的布局
View customView = LayoutInflater.from(MainActivity.this).inflate(R.layout.custom_toast,null);
ImageView img = (ImageView) customView.findViewById(R.id.iv);
TextView tv = (TextView) customView.findViewById(R.id.tv);
  //设置ImageView的图片
img.setBackgroundResource(R.drawable.ab);
  //设置textView中的文字
tv.setText("我是带图片的自定义位置的toast");
  //设置toast的View,Duration,Gravity最后显示
customToast.setView(customView);
customToast.setDuration(Toast.LENGTH_SHORT);
customToast.setGravity(Gravity.CENTER,0,0);
customToast.show();
```



## 4.自定义带动画效果的Toast控件

其实，这个就是3.带图片的toast的加强版。将里面其中的图片，改换成我们自定义的view，通过自定义view,来实现多种多样的Toast.
1.创建自定义的view.CustomToastView继承View.
整体的Custom的结构（下文会有具体实现代码）：

```java
public class CustomToastView extends View {
   //a.初始化其中的一些变量。
   ......
   //a.实现CustomToastView的3个构造函数
   ......
   //b.初始化画笔的参数和矩形参数
   .....



}1234567891011
```

a.初始化其中的一些变量，实现3个构造函数。

```java
public class CustomToastView extends View {
     //矩形，设置toast布局时用
    RectF rectF =new RectF();
    //属性动画
    ValueAnimator valueAnimator;
    float mAnimatedValue = 0f;
    //自定义view的画笔
    private Paint mPaint;

    private float mWidth = 0f; //view的宽
    private float mEyeWidth = 0f; //笑脸的眼睛半径
    private float mPadding = 0f;  //view的偏移量。
    private float endAngle = 0f; //圆弧结束的度数

    //是左眼还是右眼
    private boolean isSmileLeft = false;
    private boolean isSmileRight = false;

    public CustomToastView(Context context) {
        super(context);
    }
    public CustomToastView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
    public CustomToastView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
    .......
}

```

b.设置画笔的参数以及矩形的参数。

```java
 private void initPaint() {
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(Color.parseColor("#5cb85c"));
        mPaint.setStrokeWidth(dip2px(2));
    }
    private void initRect() {
        rectF = new RectF(mPadding, mPadding, mWidth - mPadding, mWidth - mPadding);
    }
    //dip转px。为了支持多分辨率手机
 public int dip2px(float dpValue) {
        final float scale = getContext().getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }123456789101112131415
```

c.重写onMeasure

```java
  @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        initPaint();
        initRect();
        mWidth = getMeasuredWidth(); //当前view在父布局里的宽度。即view所占宽度。
        mPadding = dip2px(10);
        mEyeWidth = dip2px(3);
    }
12345678910
```

d.重写OnDraw

```java
  @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.setStyle(Paint.Style.STROKE);
        //画微笑弧（从左向右画弧）
        canvas.drawArc(rectF, 180, endAngle, false, mPaint);
        //设置画笔为实心
        mPaint.setStyle(Paint.Style.FILL);
        //左眼
        if (isSmileLeft) {
            canvas.drawCircle(mPadding + mEyeWidth + mEyeWidth / 2, mWidth / 3, mEyeWidth, mPaint);
        }
        //右眼
        if (isSmileRight) {
            canvas.drawCircle(mWidth - mPadding - mEyeWidth - mEyeWidth / 2, mWidth / 3, mEyeWidth, mPaint);
        }
    }
```

e.自定义View中的动画效果实现

```java
  /**
     * startAnim()不带参数的方法
     */
    public void startAnim() {
        stopAnim();
        startViewAnim(0f, 1f, 2000);
    }

    /**
     * 停止动画的方法
     *
     */
    public void stopAnim() {
        if (valueAnimator != null) {
            clearAnimation();
            isSmileLeft = false;
            isSmileRight = false;
            mAnimatedValue = 0f;
            valueAnimator.end();
        }
    }
    /**
     * 开始动画的方法
     * @param startF 起始值
     * @param endF   结束值
     * @param time  动画的时间
     * @return
     */
    private ValueAnimator startViewAnim(float startF, final float endF, long time) {
        //设置valueAnimator 的起始值和结束值。
        valueAnimator = ValueAnimator.ofFloat(startF, endF);
        //设置动画时间
        valueAnimator.setDuration(time);
        //设置补间器。控制动画的变化速率
        valueAnimator.setInterpolator(new LinearInterpolator());
        //设置监听器。监听动画值的变化，做出相应方式。
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {

                mAnimatedValue = (float) valueAnimator.getAnimatedValue();
                //如果value的值小于0.5
                if (mAnimatedValue < 0.5) {
                    isSmileLeft = false;
                    isSmileRight = false;
                    endAngle = -360 * (mAnimatedValue);
                    //如果value的值在0.55和0.7之间
                } else if (mAnimatedValue > 0.55 && mAnimatedValue < 0.7) {
                    endAngle = -180;
                    isSmileLeft = true;
                    isSmileRight = false;
                    //其他
                } else {
                    endAngle = -180;
                    isSmileLeft = true;
                    isSmileRight = true;
                }
                //重绘
                postInvalidate();
            }
        });
        if (!valueAnimator.isRunning()) {
            valueAnimator.start();
        }
        return valueAnimator;
    }
```

