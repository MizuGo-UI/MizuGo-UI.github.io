---
title: Mybatis
tags: SSM
---

# Mybatis

## 简介

导入方式

<!--more-->

- maven仓库

  ```xml
  <!-- https://mvnrepository.com/artifact/org.mybatis/mybatis -->
  <dependency>
      <groupId>org.mybatis</groupId>
      <artifactId>mybatis</artifactId>
      <version>3.5.7</version>
  </dependency>
  ```

  

- Github：https://github.com/mybatis-3/releases

### 持久化（动词）

数据持久化

- 持久化就是将程序的数据在持久状态和瞬时状态转化的过程
- 内存：**断电即失**
- 数据库（jdbc),io文件持久化

### 持久层（名词）

Dao层、Service层、Controller层

- 完成持久化工作的代码块
- 层界限十分明显

### Mybatis优点

- 提供映射标签，支持对象与数据库的orm字段关系映射
- 提供对象关系映射标签，支持对象关系组建维护
- 提供xml标签，支持编写动态sql

## Hello，Mybatis！

> 步骤：搭建环境->导入Mybatis->编写代码->测试

```sql
#创建数据库
CREATE DATABASE `mybatis`;
USE `mybatis`;
#创建表
CREATE TABLE `user`(
`id` INT(20) NOT NULL PRIMARY KEY,
`name` VARCHAR(30) DEFAULT NULL,
`pwd` VARCHAR(30) DEFAULT NULL)
ENGINE=INNODB DEFAULT CHARSET=utf8;
#插入数据
INSERT INTO `user`(`id`,`name`,`pwd`)VALUES
(1,'张三','123456'),
(2,'李四','123456'),
(3,'王二','12345');
```

### 创建模块

![image-20211129154958031](../images/Mybatis/image-20211129154958031.png)

**配置xml**

> - url：连接数据库，可能会涉及到时区问题，需要与数据库的时区保持一致
> - 每一个Mapper.xml都需要在配置文件中注册

```xml
<!--xml配置文件-->
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE configuration PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-config.dtd">

<configuration>
    <!--环境配置，连接的数据库，这里使用的是MySQL-->
    <environments default="mysql">
        <environment id="mysql">
            <!--指定事务管理的类型，这里简单使用Java的JDBC的提交和回滚设置-->
            <transactionManager type="JDBC"></transactionManager>
            <!--dataSource 指连接源配置，POOLED是JDBC连接对象的数据源连接池的实现-->
            <dataSource type="POOLED">
                <property name="driver" value="com.mysql.cj.jdbc.Driver"></property>
                <property name="url" value="jdbc:mysql://127.0.0.1:3306/mybatis?useSSL=true&amp;useUnicode=true&amp;characterEncoding=UTF-8&amp;serverTimezone=UTC"></property>
                <property name="username" value="${username}"/>
        		<property name="password" value="${password}"/>
            </dataSource>
        </environment>
    </environments>
    <!--每一个Mapper.xml都需要在Mybatis核心配置文件中注册-->
    <mappers>
        <mapper resource="Mapper/UserMapper"/>
    </mappers>
</configuration>
```

**编写util工具类**

```java
/*
*Util工具类
*/
public class MybatisUtils {
    private static SqlSessionFactory sqlSessionFactory;
    static {
        try{
            //mybatis配置文件
            String resource = "mybatis-config.xml";
            InputStream inputStream = Resources.getResourceAsStream(resource);
             sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //单例模式
    public static SqlSession getSqlSession(){
        return sqlSessionFactory.openSession();
    }
}

```

### 编写代码

1. 实体类

   ```java
   public class User {
       private int id;
       private String name;
       private String pwd;
   
       public int getId() {
           return id;
       }
   
       public void setId(int id) {
           this.id = id;
       }
   
       public String getName() {
           return name;
       }
   
       public void setName(String name) {
           this.name = name;
       }
   
       public String getPwd() {
           return pwd;
       }
   
       public void setPwd(String pwd) {
           this.pwd = pwd;
       }
   
       @Override
       public String toString() {
           return "User{" +
                   "id=" + id +
                   ", name='" + name + '\'' +
                   ", pwd='" + pwd + '\'' +
                   '}';
       }
   }
   ```

2. Dao接口

   ```java
   /*
   *UserDao
   */
   public interface UserDao {
       List<User> getUserList();
   }
   ```

3. 接口实现类

   > - namespace：绑定一个对应的Dao/Mapper
   > - select id：绑定类中对应的方法，相当于用数据库语句实现了接口中的方法
   > - resultType：对应返回值的类型

   ```xml
   <!--UserMapper.xml-->
   <?xml version="1.0" encoding="UTF-8" ?>
   <!DOCTYPE mapper
           PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
           "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
   
   <mapper namespace="com.MizuGo.dao.UserDao">
       <select id="getUserList" resultType="com.MizuGo.pojo.User">
           select *from mybatis.user
       </select>
   </mapper>
   ```

### 测试

```java
public class UserDaoTest {
    @Test
    public void test(){
        //第一步，获取SqlSession对象
        SqlSession sqlSession = MybatisUtils.getSqlSession();
        //方式一：getMapper
        //getMapper映射Dao接口
        UserDao userDao = sqlSession.getMapper(UserDao.class);
        List<User> userList = userDao.getUserList();
        for (User user : userList) {
            System.out.println(user);
        }
        //关闭SqlSession
        sqlSession.close();
    }
}
```

## CURD（增删改查）

###  Select

- select id:方法名
- ResultType:返回值类型
- ParamType:参数类型

```xml
<!--根据id查询用户-->
<select id="getUserByID" resultType="com.MizuGo.pojo.User" parameterType="int">
    select * from mybatis.user where id = #{id}
</select>
```

```java
public void getUserByID(){
	SqlSession sqlSession = MybatisUtils.getSqlSession();
	UserDao userDao = sqlSession.getMapper(UserDao.class);
    
	User user = userDao.getUserByID(3);
	System.out.println(user);
	sqlSession.close();
    }
```

### Add

```xml
<!--新增用户-->
<insert id="addUser" parameterType="com.MizuGo.pojo.User">
    insert into mybatis.user value (#{id},#{name},#{pwd})
</insert>
```

```java
public void addUser(){
    SqlSession sqlSession = MybatisUtils.getSqlSession();
    UserDao userDao = sqlSession.getMapper(UserDao.class);
    
    int res = userDao.addUser(new User(4, "test", "112233"));
    //增删改提交事务才能够在数据库中生效
    sqlSession.commit();
    sqlSession.close();
}
```

**万能的Map**

> PS:这种新增方式有个弊端，当字段过多的时候同样需要人为地一个一个全部添加，极其麻烦，因此在实际的运用中，可能会采用Map的办法。
>
> 如下：可实现仅对应id插入密码

```xml
<!--通过Map查询用户-->
<insert id="addUser2" parameterType="map">
    insert into mybatis.user (id,pwd) values (#{userid},#{password});
</insert>
```

```java
public void addUser2(){
    SqlSession sqlSession = MybatisUtils.getSqlSession();
    UserDao userDao = sqlSession.getMapper(UserDao.class);
    
   Map<String, Object> map = new HashMap<String,Object>();
    map.put("userid",4);
    map.put("password","13258");
    userDao.addUser2(map);
    
    sqlSession.commit();
    sqlSession.close();
}
```

> 父类的引用指向子类的对象的好处：多态、动态链接，向上转型
>
> 1. Map<String, Object> map = new HashMap<String,Object>();
> 2. HashMap<String, Object> map = new HashMap<String,Object>();
>
> Map为HashMap的父类
>
> 第一种声明方式更加灵活，当添加新的子类的时候，不用再修改
>
> 第二种声明方式当需要实例化其他的子类，需要重新修改
>
> 当前面已经声明尖括号类型，后面尖括号中的内容可以省略

- Map传递参数，直接在sql中取出key即可 	[parameterType="map"]
- 对象传递参数，直接在sql中取对象的属性即可  [parameterType="Object"]
- 只有一个基本类型参数的情况下，可以直接在sql中取到，省略参数类型
- 多个参数用Map，或者注解

### Update

```xml
<!--修改用户-->
<update id="updateUser" parameterType="com.MizuGo.pojo.User">
    update  mybatis.user set name = #{name},pwd =#{pwd} where id =#{id}
</update>
```

```java
public void updateUser(){
    SqlSession sqlSession = MybatisUtils.getSqlSession();
    UserDao userDao = sqlSession.getMapper(UserDao.class);
    
    userDao.updateUser(new User(1,"改","987654"));
    //上传事务
    sqlSession.commit();
    sqlSession.close();
}
```

### Delete

```xml
<!--删除用户-->
<delete id="deleteUser" parameterType="int">
    delete from mybatis.user where id = #{id}
</delete>
```

```java
public void deleteUser(){
    SqlSession sqlSession = MybatisUtils.getSqlSession();
    UserDao userDao = sqlSession.getMapper(UserDao.class);

    userDao.deleteUser(4);
    sqlSession.commit();
    sqlSession.close();
}
```

### 模糊查询

1. 在sql语句使用通配符

   ```sql
   select *from mybatis.user where name like "%"#{value}"%"
   ```

2. Java执行语句中使用通配符

   ```java
   List<User> list = UserDao.likeUser("王%")；
   ```

   

```xml
<!--模糊查询-->
<select id="likeUser" resultType="com.MizuGo.pojo.User">
    select *from mybatis.user where name like #{value};
</select>
```

```java
public void likeUser(){
    SqlSession sqlSession = MybatisUtils.getSqlSession();
    UserDao userDao = sqlSession.getMapper(UserDao.class);

    List<User> list = userDao.likeUser("王%");
    for (User user : list) {
        System.out.println(user);
    }
    sqlSession.close();
}
```

## 配置解析

### 属性(properties)

**db.properties**

```properties
driver=com.mysql.cj.jdbc.Driver
url = jdbc:mysql://127.0.0.1:3306/mybatis?useSSL=true&useUnicode=true&characterEncoding=UTF-8&serverTimezone=UTC
username=root
password=981218
```

**mybatis-config.xml**

```xml
<!--第二步读取，将相关配置连接到db.properties-->
<properties resource="db.properties">
<!--首先读取-->
    <property name = "username" value = "11"></property>
</properties>
<environments default="mysql">
    <environment id="mysql">
        <!--指定事务管理的类型，分为JDBC和MANAGED两种，往往使用JDBC-->
        <transactionManager type="JDBC"></transactionManager>
        <!--dataSource 指连接源配置，POOLED是JDBC连接对象的数据源连接池的实现-->
        <dataSource type="POOLED">
            <!--第三步读取-->
            <property name="driver" value="${driver}"></property>
            <property name="url" value="${url}"></property>
            <property name="username" value="${username}"></property>
            <property name="password" value="${password}"></property>
        </dataSource>
    </environment>
</environments>
```

> 如果一个属性在不只一个地方进行了配置，那么，MyBatis 将按照下面的顺序来加载：
>
> - 首先读取在 properties 元素体内指定的属性。
> - 然后根据 properties 元素中的 resource 属性读取类路径下属性文件，或根据 url 属性指定的路径读取属性文件，并覆盖之前读取过的同名属性。
> - 最后读取作为方法参数传递的属性，并覆盖之前读取过的同名属性。

### 类型别名(typeAliases)



1. 第一种方式，直接设置缩写名

   ```xml
   <typeAliases>
       <typeAlias type="com.MizuGo.pojo.User" alias="User"/>
   </typeAliases>
   ```

2. 第二种方式，指定一个包名

   ```xml
   <typeAliases>
     <package name="com.MizuGo.pojo"/>
   </typeAliases>
   ```

   默认将类名作为缩写名，大小写均可，推荐小写

   > 类比较少的时候推荐第一种，类多选择第二种
   >
   > 两种方式都可以自定义别名，第二种方式需要在实体类用注解的方式自定义别名

```java
@Alias("user")
public class User{
    
}
```

### 设置

| 设置名             | 描述                                                         | 有效值                                                       | 默认值 |
| ------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ | ------ |
| logImpl            | 指定 MyBatis 所用日志的具体实现，未指定时将自动查找。        | SLF4J \| LOG4J \| LOG4J2 \| JDK_LOGGING \| COMMONS_LOGGING \| STDOUT_LOGGING \| NO_LOGGING | 未设置 |
| cacheEnabled       | 全局性地开启或关闭所有映射器配置文件中已配置的任何缓存。     | true \| false                                                | true   |
| lazyLoadingEnabled | 延迟加载的全局开关。当开启时，所有关联对象都会延迟加载。 特定关联关系中可通过设置 `fetchType` 属性来覆盖该项的开关状态。 | true \| false                                                | false  |

### 映射器(Mappers)

1. 使用相对于类路径的资源引用

   ```xml
   <!-- 使用相对于类路径的资源引用 -->
   <mappers>
   	<mapper resource="Mapper/UserMapper"/>
   </mappers>
   ```

2. 使用映射器接口实现类的完全限定类名

   ```xml
   <!-- 使用映射器接口实现类的完全限定类名 -->
   <mappers>
     <mapper class="com.MizuGo.dao.UserMapper"/>
   </mappers>
   ```

3. 将包内的映射器接口实现全部注册为映射器

   ```xml
   <!-- 将包内的映射器接口实现全部注册为映射器 -->
   <mappers>
     <package name="com.MizuGo.dao"/>
   </mappers>
   ```

第二种方式和第三种方式注意点：

- 接口和Mapper配置文件必须同名
- 接口和Mapper配置文件必须在同一个包下

### 作用域（Scope）和生命周期

**SqlSessionFactoryBuilder**

- 一旦创建了 SqlSessionFactory，就不再需要它了
- 作用域：方法作用域（局部方法变量）

**SqlSessionFactory**

-  一旦被创建就应该在应用的运行期间一直存在，没有任何理由丢弃它或重新创建另一个实例
- 作用域：应用作用域（全局变量）
- 单例模式或者静态单例模式

**SqlSession**

- 连接到连接池的一个请求
- SqlSession 的实例不是线程安全的，因此是不能被共享的
- 作用域：请求或方法作用域
- 用完后需要断开，否则会造成资源浪费

![image-20211201110043411](../images/Mybatis/image-20211201110043411.png)

> PS：
>
> - SqlSessionFactoryBuilder用于创建SqlSessionFactory
> - SqlSessionFactory用于创建SqlSession
> - SqlSession用于创建Mapper，一一对应

### 结果集映射(ResultMap)

解决列名不匹配问题

```xml
<resultMap id="UserMap" type="User">
    <result column="id" property="id"/>
    <result column="name" property="name"/>
    <result column="pwd" property="pwd"/>
</resultMap>

<!--查询所有用户-->
<select id="getUserList" resultMap="UserMap">
    select  * from mybatis.user;
</select>
```

指定的resultMap需要与id对应

### 分页查询

```xml
<!--分页查询-->
<select id="limitUser" parameterType="map" resultMap="UserMap">
    select*from mybatis.user limit #{startIndex},#{pageSize};
</select>
```

limit第一个参数表示开始查询的下标，第二个参数表示需要查询的长度

```java
public void limitUser(){
    SqlSession sqlSession = MybatisUtils.getSqlSession();
    UserDao userDao = sqlSession.getMapper(UserDao.class);
    HashMap<String, Integer> map = new HashMap<>();
    map.put("startIndex",0);
    map.put("pageSize",3);
    List<User> list = userDao.limitUser(map);
    for (User user : list) {
        System.out.println(list);
    }

    sqlSession.close();
}
```

## 使用注解开发

### 面向接口编程

**关于接口的理解**

- 接口从更深层次的理解，应是定义（规范，约束）与实现（名实分离的原则）的分离
- 接口的本身反应了系统设计人员对系统的抽象理解
- 接口应有两类

  - 第一类是对一个个体的抽象，可对应为一个抽象体（abstract class）
  - 第二类是对一个个体某一方面的抽象，即形成一个抽象面（interface）
- 一个个体可能有多个抽象面，抽象体与抽象面是有区别的

**三个面向区别**

- 面向对象：以对象为单位，考虑它的属性及方法
- 面向过程：以一个具体的流程为单位，考虑它的表现
- 接口设计与非接口设计是针对复用技术而言的，与面向对象（过程）不是一个问题，更多的体现的是对系统整体的架构

### 注解开发

1.注解在接口上实现

```java
/*
* UserDao.java
*/
@Select("select *from user")
List<User> getUsers();
```

2.核心文件中配置

```xml
<mappers>
    <mapper class="com.MizuGo.dao.UserDao"/>
</mappers>
```
