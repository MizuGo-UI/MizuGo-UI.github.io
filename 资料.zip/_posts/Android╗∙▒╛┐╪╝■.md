---
title: Android基本控件
date: 2021-01-11 21:40:50
urlname:
categories:
typora-root-url: Android基本控件
tags: Android
---

## RadioGroup

​       RdioGroup是单选组合框，可以容纳多个RadioButton的一个容器。在没有RadioGroup的情况下，RadioButton可以全部被选中；当多个RadioButton被RadioGroup包含的情况下，RadioButton只可以选择一个，从而达到了单选的目的。

<!--more-->

*RadioGroup相关方法*

​       1.RadioGroup.getCheckedRadioButtonId();

　　　　该方法可以获取选中的按钮

　　2.RadioGroup.clearCheck();

　　　　该方法可以清除选中状态

　　3.setOnCheckedChangeLintener(RadioGroup.OnCheckedChangeListener listener);

　　　　当一个单选按钮组中的单选按钮选中状态发生改变的时候调用的回调方法

　　4.RadioGroup.check(int id);

　　　　该方法可以通过传入ID来设置该选项为选中状态

　　5.addView(View child,int index, ViewGroup.LayoutParams params);

　　　　使用指定布局参数添加一个字视图（其中child是要添加的子视图，index是将要添加子视图的位置，params 所要添加的子视图的布局参数）

　　6.RadioButton.getText();

　　　　获取单选框的值

*RadioGroup与RadioButton的关系*

​         1.RadioButton表示单个原型单选框，而RadioGroup是可以容纳多个RadioButton的容器

　　  2.每个RadioGroup中的RadioButton同时只能有一个被选中

　　  3.不同的RadioGroup中的RadioButton互不相干，即如果组A中有一个选中了，那么组B中依然可以有一个被选中。

　　  4.在大部分场合下，一个RadioGroup中至少有两个RadioButton

　　  5.在大部分场合下，一个RadioGroup中的RadioButton默认会有一个被选中，并建议您将它放在RadioGroup的起始位置

![](../images/Android基本控件/radiogroup.gif)

​          (下面的三个按钮总体为一个RadioGroup,单独一个按钮为RadioButton)

## Selector

​       个人理解selector主要用于按钮的状态变化，如按钮按下后会变色，即两种不同的按钮状态的实现。

​       对于按钮图标的更换只需要调用一个selector文件并将按下后与按下前的图标分别对应即可:

```xml
android:drawableTop="@drawable/rb_common_frame_drawble_selector"
```

​      语句后面的内容即引用了selector，注意是在drawable目录下

​       但是对于文字的变色处理，则不能在drawable目录下进行调用，需要在color目录下进行调用，如下：

```xml
android:textColor="@color/rb_textcolor_selector"
```

对于网上所介绍的利用插件selector chapek，在drawble目录下放下两张以_normar,_pressed为后缀的图片，然后可以右键drawable目录直接调用selector，暂时未能成功。

## Bundle

​       Bundle是用来传递数据的“容器”，它保存的数据，是以key-value(键值对)的形式存在的。
我们经常使用Bundle在Activity之间传递数据，传递的数据可以是boolean、byte、int、long、float、double、string等基本类型或它们对应的数组，也可以是对象或对象数组。当Bundle传递的是对象或对象数组时，必须实现Serializable 或Parcelable接口。

```java
//新建一个Bundle类
Bundle mBundle = new Bundle();   
//bundle类中加入数据（key -value的形式，另一个activity里面取数据的时候，就要用到key，找出对应的value）
mBundle.putString("Data", "data from TestBundle");  
//新建一个intent对象，并将该bundle加入这个intent对象
Intent intent = new Intent();    
intent.setClass(TestBundle.this, Target.class);    
intent.putExtras(mBundle);  
```



## Fragment

1.关于Fragment的切换

​          Fragment的切换主要有两种方式:

​               replace();但是replace()方法会在每次切换的时候Fragment都会重新实例化，重新加载一次数据，对于用户的流量造成无端浪费，据官方文档解释，replace()方法仅适用于上一个Fragment不再需要时采用的办法。

​              另一种办法是add()，切换时show()与hide()结合使用，当切换Fragment时将当前的fragment  hide()，add()另一个fragment，再次切换时，只需要hide()当前的，show()另一个。